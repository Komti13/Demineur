package Tp2IHM;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.AbstractButton;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Demineur extends JFrame implements ActionListener{
	JPanel p1,p2;
	int i=0,nb=0;
	boolean ismine=true;
	JButton jeu[]=new JButton[36];
	int tab[]=new int[6];
	JLabel test;
	JButton nouveau,decouvrir;
	//JButton b1;
	public Demineur(String ch) {
		
		setTitle(ch);
		setSize(700,700);
		setLocation(500,50);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setLayout(new BorderLayout());
		p1=new JPanel(new GridLayout(1,3));
		p1.setPreferredSize(new Dimension(600, 30));
		 test=new JLabel("         Le nombre des erreurs :"+nb);
		 test.setForeground(Color.red);
		p1.add(test);
		p2=new JPanel(new FlowLayout());
		p2.setPreferredSize(new Dimension(600, 600));
		for(int k=0;i<36;i++) {
		
		}
		
		for(i=0;i<36;i++) {
			
			//JButton b1=new JButton(new ImageIcon("C:/Users/Dell/Desktop/clickme.png"));
			JButton b1=new JButton(""+(i+1), new ImageIcon("C:\\Users\\Dell\\Desktop\\STUFF\\Html Css\\tp html css\\int.png"));
			//JButton b1=new JButton(""+(i+1));
			jeu[i]=b1;
			jeu[i].setBackground(Color.white);
			jeu[i].setPreferredSize(new Dimension(100, 100));
			jeu[i].addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					
					if(b1.getBackground()==Color.white) {
					if(exist(Integer.parseInt(b1.getText()), tab)) {
						jeu[Integer.parseInt(b1.getText())-1].setBackground(Color.red);
						//b1.setIcon(null);
						b1.setText("Boom");
						b1.setBackground(Color.red);
						b1.setForeground(Color.white);
						b1.setIcon(new ImageIcon("C:\\Users\\Dell\\Desktop\\STUFF\\Html Css\\tp html css\\bombe.png"));

						
					nb++;
					test.setText("         Le nombre des erreurs :"+nb);
					}
					else {
						jeu[Integer.parseInt(b1.getText())-1].setBackground(Color.yellow);
						String ch=b1.getText();
						b1.setIcon(null);
						b1.setBackground(Color.yellow);
						int N=0;
						for(int j=0;j<36;j++) {
							if(jeu[j].getText().equals(ch)) {
								
								
								
								if((Integer.parseInt(ch)-1)%6==0) {
								
								if(exist(Integer.parseInt(ch)-5,tab)) {
									System.out.println("pos-5");
									N++;}
								if(exist(Integer.parseInt(ch)-6,tab)) {
									System.out.println("pos-6");
									N++;}
								if(exist(Integer.parseInt(ch)+6,tab)) {
									System.out.println("pos+6");
									N++;}
								if(exist(Integer.parseInt(ch)+1,tab)) {
									System.out.println("pos+1");
									N++;}
							
								if(exist(Integer.parseInt(ch)+7,tab)) {
									System.out.println("pos+7");
									N++;}
								}
								else if(Integer.parseInt(ch)%6==0) {
									if(exist(Integer.parseInt(ch)-7,tab)) {
										System.out.println("pos-7");
										N++;}
									
									if(exist(Integer.parseInt(ch)-6,tab)) {
										System.out.println("pos-6");
										N++;}
									
									if(exist(Integer.parseInt(ch)+6,tab)) {
										System.out.println("pos+6");
										N++;}
									if(exist(Integer.parseInt(ch)+5,tab)) {
										System.out.println("pos+5");
										N++;}
									if(exist(Integer.parseInt(ch)-1,tab)) {
										System.out.println("pos-1");
										N++;}
								}
								else {
									if(exist(Integer.parseInt(ch)-7,tab)) {
										System.out.println("pos-7");
										N++;}
									if(exist(Integer.parseInt(ch)-5,tab)) {
										System.out.println("pos-5");
										N++;}
									if(exist(Integer.parseInt(ch)-6,tab)) {
										System.out.println("pos-6");
										N++;}
									if(exist(Integer.parseInt(ch)+7,tab)) {
										System.out.println("pos+7");
										N++;}
									if(exist(Integer.parseInt(ch)+6,tab)) {
										System.out.println("pos+6");
										N++;}
									if(exist(Integer.parseInt(ch)+5,tab)) {
										System.out.println("pos+5");
										N++;}
								if(exist(Integer.parseInt(ch)+1,tab)) {
									System.out.println("pos+1");
									N++;}
								if(exist(Integer.parseInt(ch)-1,tab)) {
									System.out.println("pos-1");
									N++;}
								}
								if(N>0)
									b1.setText("!"+N+"Bombes");
								if(N==0)
									b1.setText("Zone claire");
							}
						}
					}
					
						
					
					}
					int h,v=0;
					for(h=0;h<36;h++) {
					 if((jeu[h].getBackground()==Color.yellow))
					v++;
			        }
					if(v==30)
					JOptionPane.showMessageDialog(null, "vous avez "+nb+" erreurs");
				}
				
			});
		    p2.add(jeu[i]);
		}
		nouveau=new JButton("Nouveau jeu");
		nouveau.setBackground(Color.BLUE);
		nouveau.setForeground(Color.white);
		decouvrir=new JButton("D�couvrir");
		decouvrir.setBackground(Color.BLUE);
		decouvrir.setForeground(Color.white);
		nouveau.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Remplir();
				for(int i=0;i<36;i++) {
					jeu[i].setIcon(new ImageIcon("C:\\Users\\Dell\\Desktop\\STUFF\\Html Css\\tp html css\\int.png"));
					jeu[i].setBackground(Color.white);
					jeu[i].setText(""+(i+1));
					nb=0;
					test.setText("         Le nombre des erreurs :"+nb);
				}
			}
		});
		decouvrir.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				for(int j=0;j<6;j++) {
					System.out.println(tab[j]);
					for(int i=0;i<36;i++) {
						if(jeu[i].getText().equals(""+tab[j])) {
							jeu[i].setIcon(null);
							jeu[i].setBackground(Color.red);}
					}
					
					
				}
				
			}
			@Override
			public void mouseReleased(MouseEvent e) {
				for(int j=0;j<6;j++) {
					for(int i=0;i<36;i++) {
						if(jeu[i].getText().equals(""+tab[j])) {
							jeu[i].setIcon(new ImageIcon("C:\\Users\\Dell\\Desktop\\STUFF\\Html Css\\tp html css\\int.png"));
							jeu[i].setBackground(Color.white);
						}
					}
					
				}
			}
		});
		p1.add(nouveau);
		p1.add(decouvrir);
		
		
		
		
		
		
		
		add(p1,BorderLayout.NORTH);
		add(p2,BorderLayout.CENTER);
		
		
		
	}
	void Remplir() {
		for(int j=0;j<6;j++) {
			int x=(int) (Math.random()*36);
			while(exist(x,tab)||x>=36) {
				x=(int) (Math.random()*36);
			}
			System.out.println(x);
			tab[j]=x;
			
		}
	}
	
	boolean exist(int x,int []tab) {
		if(x>0 && x<=36)
		for(int j=0;j<6;j++)
			if (tab[j]==x)
				return true;
		return false;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
	
			
		
		
	}
	public static void main(String[] args) {
		
		Demineur d=new Demineur("Demineur");
		d.Remplir();
		d.setVisible(true);
		
	}

	

}
